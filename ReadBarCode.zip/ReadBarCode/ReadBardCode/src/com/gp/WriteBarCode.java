package com.gp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class WriteBarCode {
	
	public static void main(String[] args) throws FileNotFoundException, IOException, WriterException {
		
		String URL = "www.abc.com"; 

		int width = 400;
		int height = 300; 

		String imageFormat = "png";

		BitMatrix bitMatrix = new QRCodeWriter().encode(URL, BarcodeFormat.QR_CODE, width, height);
		MatrixToImageWriter.writeToStream(bitMatrix, imageFormat, new FileOutputStream(new File("C:\\Users\\monikat\\Desktop\\Bard Code\\QRWrite.png")));
		
		System.out.println("Done with writing");
	}

}
